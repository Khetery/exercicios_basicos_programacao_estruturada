print("Bem Vindo ao Cinema!")
idade = int(input("Quantos anos você tem?"))
preco = 25
if idade <12 or idade>=65:
    preco = preco/2
print("O total é ", preco)
